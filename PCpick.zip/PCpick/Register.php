<?php

include 'Database.php';

$error = ""; // Initialize error variable

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_SPECIAL_CHARS);
    $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_SPECIAL_CHARS);
    $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_SPECIAL_CHARS);

    
    if (empty($username) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } else {
        
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        
        $st = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $st->bind_param("ss", $username, $email);
        $st->execute();
        $result = $st->get_result();
        if ($result->num_rows > 0) {
            $error = "Username or email already exists.";
        } else {
            
            $st = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $st->bind_param("sss", $username, $email, $hashedPassword);
            if ($st->execute()) {
                header("Location: Login.html");
                exit();
            } else {
                $error = "Error registering user: " . $conn->error;
            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Register.css">
    <title>Register Page</title>
</head>
<body>
<div class="register-container">
    <h2>Register</h2>
    <?php if (!empty($error)) echo "<p style='color: red;'>$error</p>"; ?> <!-- Display error message -->
    <form action="Register.php" method="post">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="form-group">
            <input type="submit" value="Register">
        </div>
    </form>
    <p>Already have an account? <a href="login.html">Login here</a>.</p>
</div>
</body>
</html>
