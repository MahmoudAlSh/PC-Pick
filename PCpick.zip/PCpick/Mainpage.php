<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PC Parts Store</title>
    <link rel="stylesheet" href="Mainpage.css">
</head>
<body>

<!-- Navigation bar -->
<div class="top-bar">
    <div class="top-bar-links">
        <a href="Mainpage.php">Home</a>
        <a href="AboutusPage.html">About Us</a>
        <a href="Orders.php">Orders</a> <!-- New link for Orders -->
    </div>
    <div class="top-bar-buttons">
        <a href="Logout.php" class="btn logout-btn">Logout</a>
        <a href="Cart.php" class="cart-link">
            <div class="cart-image-placeholder">
                <img src="cart-icon.svg" alt="Cart">
            </div>
        </a>
    </div>
</div>

<div class="container">
    <h1>PC Components Categories</h1>
    <div class="categories-grid">
        <?php
        // Define categories with their display names and icons
        $categories = [
            'case' => ['name' => 'Cases', 'icon' => 'PcCase.JPEG'],
            'motherboard' => ['name' => 'Motherboards', 'icon' => 'Motherboard.JPEG'],
            'gpu' => ['name' => 'GPUs', 'icon' => 'GPU.JPEG'],
            'cpu' => ['name' => 'CPUs', 'icon' => 'CPU.JPEG'],
            'hard drive' => ['name' => 'Hard Drives', 'icon' => 'HardDrive.JPEG'],
            'ram' => ['name' => 'RAM', 'icon' => 'RAM.JPEG'],
            'psu' => ['name' => 'PSU', 'icon' => 'PowerSupply.jpeg']
        ];
        
        include 'Database.php';
        
        foreach ($categories as $type => $info) {
            // Count products in each category
            $sql = "SELECT COUNT(*) as count FROM product WHERE type = '$type'";
            $result = $conn->query($sql);
            $count = $result->fetch_assoc()['count'];
            
            echo "<div class='category-card'>";
            echo "<div class='category-icon'>";
            echo "<img src='" . $info['icon'] . "' alt='" . $info['name'] . "'>";
            echo "</div>";
            echo "<h3>" . $info['name'] . "</h3>";
            echo "<p class='product-count'>" . $count . " products</p>";
            echo "<a href='category.php?type=" . urlencode($type) . "' class='btn category-btn'>Browse " . $info['name'] . "</a>";
            echo "</div>";
        }
        
        $conn->close();
        ?>
    </div>
</div>

<div class="footer">
    <p>&copy; 2024 PCPick. All rights reserved.</p>
</div>

</body>
</html>
