<?php
// Check if a session is not already active before starting a new one
if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Start session to access session variables
}

// Include your database connection file
include 'Database.php';

// Check if the cart session variable exists and is not empty
if(isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $cartItems = $_SESSION['cart'];
    
    // Output the cart items
    foreach ($cartItems as $item) {
        echo "<div class='cart-item'>";
        // Output cart item details
        echo "<div class='item-details'>";
        echo "<h3>" . $item["name"] . "</h3>";
        echo "<p>Price: $" . $item["price"] . "</p>";
        // Check if the "quantity" key is defined for the item
        if(isset($item["quantity"])) {
            echo "<p>Quantity: " . $item["quantity"] . "</p>";
        } else {
            echo "<p>Quantity: 1</p>"; // Default quantity if not defined
        }
        echo "</div>";
        // Output cart item image
        echo "<div class='item-image'>";
        // Retrieve the product image path from the database based on product ID
        $productId = $item['product_id'];
        $sql = "SELECT image FROM product WHERE product_id = $productId";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $imagePath = $row['image'];
            echo "<img src='$imagePath' alt='" . $item["name"] . "'>";
        } else {
            echo "<div class='no-image'>No Image Available</div>";
        }
        echo "</div>";
        // Output cart item actions (e.g., delete button)
        echo "<div class='item-actions'>";
        echo "<form method='POST' action='DeleteCartItem.php'>";
        echo "<input type='hidden' name='product_id' value='" . $item["product_id"] . "'>";
        echo "<button type='submit' class='btn-delete'>Delete</button>";
        echo "</form>";
        echo "</div>";
        echo "</div>";
    }
    
    // Calculate total price
    $totalPrice = 0;
    foreach($cartItems as $item) {
        $totalPrice += $item['price'];
    }
    
    // Display total price and checkout button
    echo "<div class='checkout'>";
    echo "<p class='total-price'>Total Price: $" . $totalPrice . "</p>";
    echo "<a href='Checkout.html' class='btn-checkout'>Checkout</a>";
    echo "</div>";
} else {
    echo "Your cart is empty.";
}

// Close the database connection
$conn->close();
?>
