<?php
// Include database connection
include 'Database.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize form inputs
    $itemName = filter_input(INPUT_POST, "itemName", FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, "description", FILTER_SANITIZE_STRING);
    $price = filter_input(INPUT_POST, "price", FILTER_VALIDATE_FLOAT);
    $quantity = filter_input(INPUT_POST, "quantity", FILTER_VALIDATE_INT);
    $image = filter_input(INPUT_POST, "image", FILTER_SANITIZE_URL);
    $type = filter_input(INPUT_POST, "type", FILTER_SANITIZE_STRING);

    // Validate form inputs
    if (empty($itemName) || empty($description) || empty($price) || empty($quantity) || empty($image) || empty($type)) {
        echo "All fields are required.";
        exit();
    }

    // Prepare SQL statement to insert item into the database
    $stmt = $conn->prepare("INSERT INTO product (name, description, price, stock, image, type) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdiss", $itemName, $description, $price, $quantity, $image, $type);

    // Execute the SQL statement
    if ($stmt->execute()) {
        echo "Item added successfully.";
        header("Location: Admin.php");
        exit(); 
    } else {
        echo "Error adding item: " . $stmt->error;
    }

    // Close the statement and database connection
    $stmt->close();
    $conn->close();
}
?>
