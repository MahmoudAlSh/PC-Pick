<?php
session_start(); // Start session to access session variables

// Check if product_id is provided
if(isset($_POST['product_id'])) {
    // Retrieve product ID from the POST request
    $product_id = $_POST['product_id'];

    // Assuming you have a database connection established in Database.php
    include 'Database.php';

    // Retrieve product details from the database based on the product ID
    $sql = "SELECT * FROM product WHERE product_id = $product_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Check if cart exists in the session, if not, initialize an empty array
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Add the product to the cart session variable
        $_SESSION['cart'][] = [
            'product_id' => $row['product_id'],
            'name' => $row['name'],
            'price' => $row['price']
        ];

        // Send a success response
        http_response_code(200);
        echo json_encode(['message' => 'Product added to cart successfully.']);
    } else {
        // Send an error response if the product is not found
        http_response_code(404);
        echo json_encode(['error' => 'Product not found.']);
    }

    $conn->close(); // Close database connection
} else {
    // Send an error response if the product ID is not provided
    http_response_code(400);
    echo json_encode(['error' => 'Product ID is not provided.']);
}
?>
