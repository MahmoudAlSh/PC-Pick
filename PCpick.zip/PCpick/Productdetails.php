<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Detail</title>
    <link rel="stylesheet" href="Productdetails.css">
</head>
<body>

<div class="top-bar">
    <div class="top-bar-links">
        <a href="Mainpage.php">Home</a>
        <a href="AboutusPage.html">About Us</a>
        <a href="Orders.php">Orders</a>
    </div>
    <div class="top-bar-buttons">
        <a href="Logout.php" class="btn logout-btn">Logout</a>
        <a href="Cart.php" class="cart-link">
            <div class="cart-image-placeholder">
                <img src="cart-icon.svg" alt="Cart">
            </div>
        </a>
    </div>
</div>

<div class="container">
<?php
session_start(); // Start session to access session variables

// Include database connection
include 'Database.php';

// Check if product_id is set in the URL
if(isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];

    // Fetch product details from the database
    $sql = "SELECT * FROM product WHERE product_id = $product_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "<div class='item'>";
        echo "<h2>" . $row["name"] . "</h2>";
        echo "<div class='photo'>";
        echo "<img src='" . $row["image"] . "' alt='" . $row["name"] . "'>";
        echo "<div class='details'>";
        echo "<h3>" . $row["description"] . "</h3>";
        echo "<p class='price'>Price: <strong>$" . $row["price"] . "</strong></p>";
        echo "</div></div>";
        echo "<button class='btn add-to-cart-btn' data-product-id='".$row['product_id']."'>Add to Cart</button>";
        echo "</div>";
    } else {
        echo "Product not found.";
    }
} else {
    echo "Product ID is not specified.";
}

$conn->close(); // Close database connection
?>

</div>

<!-- Add the script block here -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Select the Add to Cart buttons
    var addToCartButtons = document.querySelectorAll('.add-to-cart-btn');

    // Add click event listener to each button
    addToCartButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            var productId = this.getAttribute('data-product-id');
            addToCart(productId);
        });
    });

    function addToCart(productId) {
        // Send AJAX request to AddToCart.php
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    // Product added to cart successfully
                    var response = JSON.parse(xhr.responseText);
                    alert(response.message);
                } else {
                    // Failed to add product to cart
                    var error = JSON.parse(xhr.responseText);
                    alert(error.error);
                }
            }
        };
        xhr.open('POST', 'AddToCart.php');
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.send('product_id=' + productId);
    }
});

</script>

</body>
</html>
