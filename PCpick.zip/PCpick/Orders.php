<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Orders</title>
    <link rel="stylesheet" href="Mainpage.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 30px;
            display: block;
            flex: 1;
        }
        
        .order {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            width: 100%;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
        }
        
        .order::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .order h2 {
            color: #333;
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid rgba(102, 126, 234, 0.1);
        }
        
        .order > div:not(.product) {
            color: #666;
            font-size: 16px;
            line-height: 1.8;
            margin-bottom: 8px;
        }

        .product {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            margin: 15px 0;
            display: flex;
            align-items: center;
            gap: 20px;
            border: 1px solid #e9ecef;
            transition: all 0.3s ease;
        }
        
        .product:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .product img {
            max-width: 100px;
            max-height: 100px;
            border-radius: 12px;
            object-fit: contain;
            background: white;
            padding: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        .product-details {
            flex-grow: 1;
        }

        .product h3 {
            color: #333;
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .product div {
            color: #666;
            margin: 5px 0;
            font-size: 14px;
        }
        
        .no-orders {
            text-align: center;
            color: #666;
            font-size: 18px;
            padding: 50px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
    </style>
</head>
<body>

<!-- Navigation bar -->
<div class="top-bar">
    <div class="top-bar-links">
        <a href="Mainpage.php">Home</a>
        <a href="AboutusPage.html">About Us</a>
        <a href="Orders.php">Orders</a>
    </div>
    <div class="top-bar-buttons">
        <a href="Login.html" class="btn logout-btn">Logout</a>
        <a href="Cart.php" class="cart-link">
            <div class="cart-image-placeholder">
                <img src="cart-icon.svg" alt="Cart">
            </div>
        </a>
    </div>
</div>

<!-- Orders -->
<div class="container">
<?php
// Start session
session_start();

// Check if the user is logged in
if(!isset($_SESSION['userID'])) {
    // If not logged in, redirect to the login page
    header("Location: Login.html");
    exit(); // Stop further execution of the script
}

// Include database connection
include 'Database.php';

// Fetch orders for the logged-in user
$user_id = $_SESSION['userID']; // Assuming you store the user's ID in the session
$sql_orders = "SELECT * FROM orders WHERE userID = $user_id";
$result_orders = $conn->query($sql_orders);

if ($result_orders->num_rows > 0) {
    // Output each order
    while($row = $result_orders->fetch_assoc()) {
        // Output order details
        echo "<div class='order'>";
        echo "<h2>Order ID: " . $row["orderID"] . "</h2>";
        echo "Name: " . $row["firstname"] . " " . $row["lastname"] . "<br>";
        echo "Email: " . $row["email"] . "<br>";
        echo "Address: " . $row["address"] . ", " . $row["city"] . ", " . $row["country"] . "<br>";
        echo "Payment Method: " . $row["payment"] . "<br>";
        echo "Status: ". $row["status"]."<br>";

        // Check if total_price is set before accessing it
        if(isset($row["Total_Price"])) {
            echo "Total Price: $" . $row["Total_Price"] . "<br>";
        } else {
            echo "Total Price: N/A <br>";
        }

        // Fetch products associated with the order
        $order_id = $row["orderID"];
        $sql_products = "SELECT product.name, product.price, product.image, order_products.quantity
                         FROM order_products
                         INNER JOIN product ON order_products.product_id = product.product_id
                         WHERE order_products.orderID = $order_id";

        $result_products = $conn->query($sql_products);

        if ($result_products->num_rows > 0) {
            // Output product details
            while($row_product = $result_products->fetch_assoc()) {
                echo "<div class='product'>";
                echo "<img src='" . $row_product["image"] . "' alt='" . $row_product["name"] . "'>";
                echo "<div class='product-details'>";
                echo "<h3>" . $row_product["name"] . "</h3>";
                echo "<div>Price: $" . $row_product["price"] . "</div>";
                echo "<div>Quantity: " . $row_product["quantity"] . "</div>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<div class='no-orders'>No products found for this order.</div>";
        }

        echo "</div>"; // End of order
    }
} else {
    echo "<div class='no-orders'>No orders found. Start shopping to see your orders here!</div>";
}

// Close database connection
$conn->close();
?>
</div>

<div class="footer" style="background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); padding: 30px; text-align: center; margin-top: auto; border-top: 1px solid rgba(255, 255, 255, 0.2); color: #666; font-weight: 500; width: 100%;">
    <p>&copy; 2024 PCpick. All rights reserved.</p>
</div>

</body>
</html>
