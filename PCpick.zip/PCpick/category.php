<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PC Parts Store - Category</title>
    <link rel="stylesheet" href="Mainpage.css">
</head>
<body>

<!-- Navigation bar -->
<div class="top-bar">
    <div class="top-bar-links">
        <a href="Mainpage.php">Home</a>
        <a href="AboutusPage.html">About Us</a>
        <a href="Orders.php">Orders</a>
    </div>
    <div class="top-bar-buttons">
        <a href="Logout.php" class="btn logout-btn">Logout</a>
        <a href="Cart.php" class="cart-link">
            <div class="cart-image-placeholder">
                <img src="cart-icon.svg" alt="Cart">
            </div>
        </a>
    </div>
</div>

<div class="container">
    <?php
    include 'Database.php';
    
    $type = isset($_GET['type']) ? $_GET['type'] : '';
    
    // Define category display names
    $categoryNames = [
        'case' => 'Cases',
        'motherboard' => 'Motherboards',
        'gpu' => 'GPUs',
        'cpu' => 'CPUs',
        'hard drive' => 'Hard Drives',
        'ram' => 'RAM',
        'psu' => 'PSU'
    ];
    
    $categoryName = isset($categoryNames[$type]) ? $categoryNames[$type] : 'Products';
    echo "<h1>$categoryName</h1>";
    
    if ($type) {
        $sql = "SELECT * FROM product WHERE type = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $type);
        $stmt->execute();
        $result = $stmt->get_result();
        
        echo "<div class='categories-grid'>";
        
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='item'>";
                echo "<h2>" . htmlspecialchars($row["name"]) . "</h2>";
                echo "<div class='photo'>";
                echo "<img src='" . htmlspecialchars($row["image"]) . "' alt='" . htmlspecialchars($row["name"]) . "'>";
                echo "</div>";
                echo "<p class='price'>Price: <strong>$" . $row["price"] . "</strong></p>";
                echo "<a href='ProductDetails.php?product_id=" . $row["product_id"] . "' class='btn'>View Details</a>";
                echo "</div>";
            }
        } else {
            echo "<p>No products found in this category.</p>";
        }
        
        echo "</div>";
        $stmt->close();
    } else {
        echo "<p>Invalid category.</p>";
    }
    
    $conn->close();
    ?>
</div>

</body>
</html>