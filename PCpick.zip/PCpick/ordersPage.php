

<?php

// Include database connection
include 'Database.php';

// Process status update if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['order_id']) && isset($_POST['status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];
    
    // Update the order status in the database
    $update_sql = "UPDATE orders SET status = ? WHERE orderID = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $status, $order_id);
    
    if ($stmt->execute()) {
        // Status updated successfully
        echo "<script>alert('Order status updated successfully!');</script>";
    } else {
        // Error updating status
        echo "<script>alert('Error updating order status: " . $conn->error . "');</script>";
    }
    
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Management</title>
    <link rel="stylesheet" href="Mainpage.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 30px;
            display: block;
            flex: 1;
        }
        
        .order {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            width: 100%;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
        }
        
        .order::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .order h2 {
            color: #333;
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid rgba(102, 126, 234, 0.1);
        }
        
        .order > div:not(.product) {
            color: #666;
            font-size: 16px;
            line-height: 1.8;
            margin-bottom: 8px;
        }

        .product {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            margin: 15px 0;
            display: flex;
            align-items: center;
            gap: 20px;
            border: 1px solid #e9ecef;
            transition: all 0.3s ease;
        }
        
        .product:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .product img {
            max-width: 100px;
            max-height: 100px;
            border-radius: 12px;
            object-fit: contain;
            background: white;
            padding: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        .product-details {
            flex-grow: 1;
        }

        .product h3 {
            color: #333;
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .product div {
            color: #666;
            margin: 5px 0;
            font-size: 14px;
        }
        
        .no-orders {
            text-align: center;
            color: #666;
            font-size: 18px;
            padding: 50px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 600;
            margin-left: 10px;
        }
        
        .status-preparing {
            background-color: #ffeaa7;
            color: #d35400;
        }
        
        .status-delivery {
            background-color: #81ecec;
            color: #00b894;
        }
        
        .status-delivered {
            background-color:rgb(201, 223, 80);
            color:rgb(0, 0, 0);
        }
        
        .status-controls {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .status-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .preparing-btn {
            background-color: #ffeaa7;
            color: #d35400;
        }
        
        .delivery-btn {
            background-color: #81ecec;
            color:rgb(1, 160, 128);
        }
        
        .delivered-btn {
            background-color:rgb(243, 240, 38);
            color:rgb(172, 154, 0);
        }
        
        .status-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .page-title {
            font-size: 2.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 40px;
            font-weight: 700;
            text-align: center;
        }
    </style>

<body>

<!-- Orders -->
<div class="container">
    <h1 class="page-title">Order Management</h1>
    
    <?php
    // Fetch all orders from the database
    $sql_orders = "SELECT * FROM orders ORDER BY orderID DESC";
    $result_orders = $conn->query($sql_orders);

    if ($result_orders->num_rows > 0) {
        // Output each order
        while($row = $result_orders->fetch_assoc()) {
            // Determine status badge class
            $status_class = "";
            switch($row["status"]) {
                case "preparing order":
                    $status_class = "status-preparing";
                    break;
                case "in delivery":
                    $status_class = "status-delivery";
                    break;
                case "delivered":
                    $status_class = "status-delivered";
                    break;
                default:
                    $status_class = "";
            }
            
            // Output order details
            echo "<div class='order'>";
            echo "<h2>Order ID: " . $row["orderID"] . " <span class='status-badge " . $status_class . "'>" . $row["status"] . "</span></h2>";
            echo "<div>Name: " . $row["firstname"] . " " . $row["lastname"] . "</div>";
            echo "<div>Email: " . $row["email"] . "</div>";
            echo "<div>Address: " . $row["address"] . ", " . $row["city"] . ", " . $row["country"] . "</div>";
            echo "<div>Payment Method: " . $row["payment"] . "</div>";
            
            // Check if total_price is set before accessing it
            if(isset($row["Total_Price"])) {
                echo "<div>Total Price: $" . $row["Total_Price"] . "</div>";
            } else {
                echo "<div>Total Price: N/A</div>";
            }

            // Fetch products associated with the order
            $order_id = $row["orderID"];
            $sql_products = "SELECT product.name, product.price, product.image, order_products.quantity
                             FROM order_products
                             INNER JOIN product ON order_products.product_id = product.product_id
                             WHERE order_products.orderID = $order_id";

            $result_products = $conn->query($sql_products);

            if ($result_products->num_rows > 0) {
                // Output product details
                while($row_product = $result_products->fetch_assoc()) {
                    echo "<div class='product'>";
                    echo "<img src='" . $row_product["image"] . "' alt='" . $row_product["name"] . "'>";
                    echo "<div class='product-details'>";
                    echo "<h3>" . $row_product["name"] . "</h3>";
                    echo "<div>Price: $" . $row_product["price"] . "</div>";
                    echo "<div>Quantity: " . $row_product["quantity"] . "</div>";
                    echo "</div>";
                    echo "</div>";
                }
            } else {
                echo "<div>No products found for this order.</div>";
            }
            
            // Add status update controls
            echo "<div class='status-controls'>";
            echo "<form method='post' action='ordersPage.php' style='display:inline;'>";
            echo "<input type='hidden' name='order_id' value='" . $row["orderID"] . "'>";
            echo "<input type='hidden' name='status' value='preparing order'>";
            echo "<button type='submit' class='status-btn preparing-btn'>Mark as Preparing</button>";
            echo "</form>";
            
            echo "<form method='post' action='ordersPage.php' style='display:inline;'>";
            echo "<input type='hidden' name='order_id' value='" . $row["orderID"] . "'>";
            echo "<input type='hidden' name='status' value='in delivery'>";
            echo "<button type='submit' class='status-btn delivery-btn'>Mark as In Delivery</button>";
            echo "</form>";
            
            echo "<form method='post' action='ordersPage.php' style='display:inline;'>";
            echo "<input type='hidden' name='order_id' value='" . $row["orderID"] . "'>";
            echo "<input type='hidden' name='status' value='delivered'>";
            echo "<button type='submit' class='status-btn delivered-btn'>Mark as Delivered</button>";
            echo "</form>";
            echo "</div>";
            
            echo "</div>"; // End of order
        }
    } else {
        echo "<div class='no-orders'>No orders found.</div>";
    }

    // Close database connection
    $conn->close();
    ?>
</div>



</body>
</html>