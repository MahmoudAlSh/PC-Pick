<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Page</title>
    <link rel="stylesheet" href="Adminpage.css">
</head>
<body>
    <div class="container">
        <h1>Add Item</h1>
        <form id="addItemForm" action="create.php" method="post">
            <input type="text" name="itemName" placeholder="Item Name" required>
            <textarea name="description" placeholder="Description" required></textarea>
            <input type="number" name="price" placeholder="Price" required>
            <input type="number" name="quantity" placeholder="Quantity" required>
            <input type="text" name="image" placeholder="Image" required>
            <select name="type" required>
                <option value="">Select Category</option>
                <option value="case">Case</option>
                <option value="motherboard">Motherboard</option>
                <option value="gpu">GPU</option>
                <option value="cpu">CPU</option>
                <option value="hard drive">Hard Drive</option>
                <option value="ram">RAM</option>
                <option value="psu">PSU</option>
            </select>
            <button type="submit" class="btn add-btn">Add Product</button>
        </form>

        <h1>Items</h1>
        <?php
        // Include database connection
        include 'Database.php';

        // Fetch items from the database
        $sql = "SELECT * FROM product";
        $result = $conn->query($sql);

        echo "<div class='products-grid'>";
        
        // Check if there are items
        if ($result->num_rows > 0) {
            // Output each item with edit and delete buttons
            while($row = $result->fetch_assoc()) {
                $type = isset($row['type']) ? $row['type'] : 'N/A';
                echo "<div class='admin-item'>";
                echo "<div class='item-image'>";
                echo "<img src='{$row['image']}' alt='{$row['name']}'>";
                echo "</div>";
                echo "<div class='item-details'>";
                echo "<h3>{$row['name']}</h3>";
                echo "<p class='item-description'>{$row['description']}</p>";
                echo "<div class='item-info'>";
                echo "<span class='price'>$" . $row['price'] . "</span>";
                echo "<span class='stock'>Stock: " . $row['stock'] . "</span>";
                echo "<span class='category'>Category: " . ucfirst($type) . "</span>";
                echo "</div>";
                echo "<div class='item-actions'>";
                echo "<button class='btn edit-btn' onclick=\"window.location='Edit.php?product_id=".$row['product_id']."';\">Edit</button>";
                echo "<form action='Delete.php' method='post' style='display: inline;'>";
                echo "<input type='hidden' name='itemId' value='{$row['product_id']}'>";
                echo "<button type='submit' class='btn delete-btn' onclick='return confirm(\"Are you sure you want to delete this item?\")'>Delete</button>";
                echo "</form>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<p class='no-items'>No items found.</p>";
        }
        
        echo "</div>";
        ?>
    </div>
</body>
</html>
