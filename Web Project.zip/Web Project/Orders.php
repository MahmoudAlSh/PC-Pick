<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thank You</title>
    <link rel="stylesheet" href="Mainpage.css">
    <style>
        .order {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 20px;
            width: 600px; /* Set a fixed width for the order container */
        }

        .order h2 {
            margin-top: 0;
        }

        .product {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
            display: flex; /* Use flexbox to align items */
        }

        .product img {
            max-width: 100px;
            max-height: 100px;
            margin-right: 10px;
        }

        /* Adjust width of product details to fit within the container */
        .product h3,
        .product p {
            width: 400px; /* Adjust width as needed */
        }
    </style>
</head>
<body>

<!-- Navigation bar -->
<div class="top-bar">
    <div class="top-bar-links">
        <a href="Mainpage.php">Home</a>
        <a href="AboutusPage.html">About Us</a>
        <a href="Order.php">Orders</a>
    </div>
    <div class="top-bar-buttons">
        <a href="Login.html" class="btn logout-btn">Logout</a>
        <a href="Cart.php" class="cart-link">
            <div class="cart-image-placeholder">
                <img src="cart.png" alt="Cart">
            </div>
        </a>
    </div>
</div>

<!-- Orders -->
<div class="container">
<?php
// Start session
session_start();

// Check if the user is logged in
if(!isset($_SESSION['userID'])) {
    // If not logged in, redirect to the login page
    header("Location: Login.html");
    exit(); // Stop further execution of the script
}

// Include database connection
include 'Database.php';

// Fetch orders for the logged-in user
$user_id = $_SESSION['userID']; // Assuming you store the user's ID in the session
$sql_orders = "SELECT * FROM orders WHERE userID = $user_id";
$result_orders = $conn->query($sql_orders);

if ($result_orders->num_rows > 0) {
    // Output each order
    while($row = $result_orders->fetch_assoc()) {
        // Output order details
        echo "<div class='order'>";
        echo "<h2>Order ID: " . $row["orderID"] . "</h2>";
        echo "Name: " . $row["firstname"] . " " . $row["lastname"] . "<br>";
        echo "Email: " . $row["email"] . "<br>";
        echo "Address: " . $row["address"] . ", " . $row["city"] . ", " . $row["country"] . "<br>";
        echo "Payment Method: " . $row["payment"] . "<br>";

        // Check if total_price is set before accessing it
        if(isset($row["Total_Price"])) {
            echo "Total Price: $" . $row["Total_Price"] . "<br>";
        } else {
            echo "Total Price: N/A <br>";
        }

        // Fetch products associated with the order
        $order_id = $row["orderID"];
        $sql_products = "SELECT product.name, product.price, product.image, order_products.quantity
                         FROM order_products
                         INNER JOIN product ON order_products.product_id = product.product_id
                         WHERE order_products.orderID = $order_id";

        $result_products = $conn->query($sql_products);

        if ($result_products->num_rows > 0) {
            // Output product details
            while($row_product = $result_products->fetch_assoc()) {
                echo "<div class='product'>";
                echo "<img src='" . $row_product["image"] . "' alt='" . $row_product["name"] . "'>";
                echo "<h3>Name: " . $row_product["name"] . "</h3>";
                echo "Price: $" . $row_product["price"] . "<br>";
                echo "Quantity: " . $row_product["quantity"] . "<br>";
                echo "</div>";
            }
        } else {
            echo "No products found for this order.";
        }

        echo "</div>"; // End of order
    }
} else {
    echo "No orders found.";
}

// Close database connection
$conn->close();
?>
