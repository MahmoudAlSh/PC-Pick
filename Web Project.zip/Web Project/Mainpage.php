<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PC Parts Store</title>
    <link rel="stylesheet" href="Mainpage.css">
</head>
<body>

<!-- Navigation bar -->
<div class="top-bar">
    <div class="top-bar-links">
        <a href="Mainpage.php">Home</a>
        <a href="AboutusPage.html">About Us</a>
        <a href="Orders.php">Orders</a> <!-- New link for Orders -->
    </div>
    <div class="top-bar-buttons">
        <a href="Logout.php" class="btn logout-btn">Logout</a>
        <a href="Cart.php" class="cart-link">
            <div class="cart-image-placeholder">
                <img src="cart.png" alt="Cart">
            </div>
        </a>
    </div>
</div>

<div class="container">
    <?php
    include 'Database.php';
    
    $sql = "SELECT * FROM product";
    $result = $conn->query($sql);

    // Output the products in HTML format
    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<div class='item'>";
            echo "<h2>" . $row["name"] . "</h2>";
            echo "<div class='photo'>";
            echo "<img src='" . $row["image"] . "' alt='" . $row["name"] . "'>";
            echo "</div>";
            echo "<p class='price'>Price: <strong>$" . $row["price"] . "</strong></p>"; // Modified line
            echo "<a href='ProductDetails.php?product_id=" . $row["product_id"] . "' class='btn'>View Details</a>";
            echo "</div>";
        }
    } else {
        echo "0 results";
    }
    $conn->close();
    ?>
</div>

<div class="footer">
    <p>&copy; 2024 PCpick. All rights reserved.</p>
</div>

</body>
</html>
