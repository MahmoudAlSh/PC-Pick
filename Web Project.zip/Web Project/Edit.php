<?php
// Include database connection
include 'Database.php';

// Initialize variables
$itemId = $itemName = $description = $price = $quantity = $image = "";

// Check if the form was submitted for fetching item details
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Get the item ID from the query string
    $editItemId = filter_input(INPUT_GET, "product_id", FILTER_VALIDATE_INT);

    // Validate the item ID
    if (empty($editItemId)) {
        echo "Invalid item ID.";
        exit();
    }

    // Prepare and execute SQL statement to fetch item details
    $stmt = $conn->prepare("SELECT * FROM product WHERE product_id = ?");
    $stmt->bind_param("i", $editItemId);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the item exists
    if ($result->num_rows == 1) {
        // Fetch item details
        $row = $result->fetch_assoc();
        $itemId = $row['product_id'];
        $itemName = $row['name'];
        $description = $row['description'];
        $price = $row['price'];
        $quantity = $row['stock'];
        $image = $row['image'];
    } else {
        echo "Item not found.";
        exit();
    }

    // Close the statement
    $stmt->close();
}

// Check if the form was submitted for updating item details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize form inputs
    $editItemId = filter_input(INPUT_POST, "itemId", FILTER_VALIDATE_INT);
    $editItemName = filter_input(INPUT_POST, "editItemName", FILTER_SANITIZE_STRING);
    $editDescription = filter_input(INPUT_POST, "editDescription", FILTER_SANITIZE_STRING);
    $editPrice = filter_input(INPUT_POST, "editPrice", FILTER_VALIDATE_FLOAT);
    $editQuantity = filter_input(INPUT_POST, "editQuantity", FILTER_VALIDATE_INT);
    $editImage = filter_input(INPUT_POST, "editImage", FILTER_SANITIZE_URL);

    // Validate form inputs
    if (empty($editItemId) || empty($editItemName) || empty($editDescription) || $editPrice === false || $editQuantity === false || empty($editImage)) {
        echo "All fields are required.";
        exit();
    }

    // Prepare SQL statement to update item in the database
    $stmt = $conn->prepare("UPDATE product SET name = ?, description = ?, price = ?, stock = ?, image = ? WHERE product_id = ?");
    $stmt->bind_param("ssdisi", $editItemName, $editDescription, $editPrice, $editQuantity, $editImage, $editItemId);

    // Execute the SQL statement
    if ($stmt->execute()) {
        echo "Item updated successfully.";
        header("Location: Admin.php");
        exit(); // Ensure script stops executing after redirect
    } else {
        echo "Error updating item: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Item</title>
    <link rel="stylesheet" href="Adminpage.css">
</head>
<body>
    <div class="container">
        <h1>Edit Item</h1>
        <form id="editItemForm" action="Edit.php" method="post">
            <input type="hidden" name="itemId" value="<?php echo $itemId; ?>"> <!-- Include hidden input field for item ID -->
            <input type="text" name="editItemName" placeholder="Item Name" value="<?php echo $itemName; ?>" required> <!-- Include input field for edited item name -->
            <input type="text" name="editDescription" placeholder="Description" value="<?php echo $description; ?>" required>
            <input type="number" name="editPrice" placeholder="Price" value="<?php echo $price; ?>" required>
            <input type="number" name="editQuantity" placeholder="Quantity" value="<?php echo $quantity; ?>" required>
            <input type="text" name="editImage" placeholder="Image" value="<?php echo $image; ?>" required>
            <button type="submit">Edit</button>
        </form>
    </div>
</body>
</html>
