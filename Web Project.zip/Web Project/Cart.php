<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cart</title>
    <!-- Include your CSS files here -->
    <link rel="stylesheet" href="Cart.css">
</head>
<body>

<!-- Your navigation bar or header content here -->
<div class="top-bar">
    <div class="top-bar-links">
        <a href="Mainpage.php">Home</a>
        <a href="AboutusPage.html">About Us</a>
        <a href="Orders.php">Orders</a>
    </div>
    <div class="top-bar-buttons">
        <a href="Logout.php" class="btn logout-btn">Logout</a>
        <a href="Cart.php" class="cart-link">
            <div class="cart-image-placeholder">
                <img src="cart.png" alt="Cart">
            </div>
        </a>
    </div>
</div>

<div class="cart-container">
    <!-- Include the PHP file that displays cart content -->
    <?php include 'Cart_content.php'; ?>
</div>

<!-- Include your other scripts here -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Select all delete buttons
    var deleteButtons = document.querySelectorAll('.btn-delete');

    // Add click event listener to each delete button
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            // Submit the form when delete button is clicked
            this.closest('form').submit();
        });
    });
});
</script>

</body>
</html>
