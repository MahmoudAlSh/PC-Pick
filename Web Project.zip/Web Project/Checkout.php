<?php
session_start(); // Start session

include 'Database.php'; // Include database connection

$error = ""; // Initialize error variable

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize form inputs
    $firstname = filter_input(INPUT_POST, "firstname", FILTER_SANITIZE_SPECIAL_CHARS);
    $lastname = filter_input(INPUT_POST, "lastname", FILTER_SANITIZE_SPECIAL_CHARS);
    $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
    $address = filter_input(INPUT_POST, "address", FILTER_SANITIZE_SPECIAL_CHARS);
    $country = filter_input(INPUT_POST, "country", FILTER_SANITIZE_SPECIAL_CHARS);
    $city = filter_input(INPUT_POST, "city", FILTER_SANITIZE_SPECIAL_CHARS);
    $payment = filter_input(INPUT_POST, "payment", FILTER_SANITIZE_SPECIAL_CHARS);
    
    // Check if the necessary session variables are set
    if (isset($_SESSION['userID'])) {
        // Get user ID from session
        $userID = $_SESSION['userID'];
        
        // Check if the cart session variable exists and is not empty
        if(isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
            $cartItems = $_SESSION['cart'];

            // Calculate total price
            $totalPrice = 0;
            foreach($cartItems as $item) {
                $totalPrice += $item['price'];
            }
            
            // Insert data into orders table using prepared statement
            $stmt = $conn->prepare("INSERT INTO orders (userID, firstname, lastname, email, address, country, city, payment, total_price) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("isssssssd", $userID, $firstname, $lastname, $email, $address, $country, $city, $payment, $totalPrice);
            
            if ($stmt->execute()) {
                // Get the order ID of the inserted order
                $orderID = $conn->insert_id;
                
                // Insert product IDs into order_products table
                foreach($cartItems as $item) {
                    $productID = $item['product_id'];
                    $quantity = isset($item['quantity']) ? $item['quantity'] : 1; // Default quantity is 1 if not specified
                    
                    $stmt = $conn->prepare("INSERT INTO order_products (orderID, product_id, quantity) VALUES (?, ?, ?)");
                    $stmt->bind_param("iid", $orderID, $productID, $quantity);
                    if ($stmt->execute() !== TRUE) {
                        // Log error to file or database
                        error_log("Error inserting product ID: " . $stmt->error);
                    }
                }
                
                // Clear the cart after placing the order
                unset($_SESSION['cart']);
                
                // Redirect to order confirmation page
                header("Location: Confirm.html");
                exit();
            } else {
                // Log error to file or database
                error_log("Error placing order: " . $stmt->error);
                $error = "Error placing order. Please try again later.";
            }
        } else {
            $error = "Your cart is empty.";
        }
    } else {
        // UserID is not set in session
        $error = "User ID not found.";
    }
}

// Display error message if any
if (!empty($error)) {
    echo "<p>Error: $error</p>";
}
?>
