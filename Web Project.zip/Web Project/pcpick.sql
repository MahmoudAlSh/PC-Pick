-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2024 at 09:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pcpick`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `country` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `Total_Price` decimal(11,0) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderID`, `userID`, `country`, `address`, `firstname`, `lastname`, `email`, `city`, `payment`, `Total_Price`, `product_id`) VALUES
(15, 10, 'Saudi Arabia', 'IAU', 'Hassan', 'ana', 'hassan@hotmail.com', 'Dammam', 'cash', 680, NULL),
(18, 13, 'Saudi Arabia', '25 street', 'ali', 'ali', 'ali@hotmail.com', 'Dammam', 'cash', 130, NULL),
(19, 16, 'Saudi Arabia', '1b street', 'ahmed', 'alrashed', 'ahmed@hotmail.com', 'Dammam', 'cash', 50, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `order_product_id` int(11) NOT NULL,
  `orderID` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`order_product_id`, `orderID`, `product_id`, `quantity`) VALUES
(20, 15, 1, 1),
(21, 15, 2, 1),
(22, 15, 3, 1),
(23, 15, 6, 1),
(24, 15, 6, 1),
(28, 18, 1, 1),
(29, 18, 6, 1),
(30, 18, 6, 1),
(31, 19, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(11,0) NOT NULL,
  `stock` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `name`, `description`, `price`, `stock`, `image`) VALUES
(1, 'NZXT H5 Flow RGB Compact ATX Mid-Tower Computer Case/Gaming Cabinet - White', 'The NZXT H5 Flow RGB is a stylish mid-tower PC case in white with excellent airflow, integrated RGB lighting, and easy installation, ideal for gaming and workstations.', 50, 100, 'PcCase.JPEG'),
(2, 'MSI PRO Z690-A DDR4 ProSeries Motherboard', 'The MSI PRO Z690-A DDR4 motherboard is built for Intel&#39;s 12th Gen processors, offering reliable performance and advanced features like DDR4 memory support, PCIe Gen 5, and USB 3.2 Gen 2x2. Ideal for gaming and professional applications.', 150, 50, 'Motherboard.JPEG'),
(3, 'GIGABYTE GeForce RTX 3060 Gaming OC 12G', 'The GIGABYTE GeForce RTX 3060 Gaming OC 12G offers smooth gaming performance, enhanced by its triple-fan cooling solution and sleek RGB aesthetics.', 400, 30, 'GPU.JPEG'),
(4, 'Intel Core i7-12700K Desktop Processor 12th gen', 'The Intel Core i7-12700K is a powerful 12th generation desktop processor, delivering high performance for gaming and productivity tasks with its advanced architecture and efficient design.', 300, 20, 'CPU.JPEG'),
(5, 'Samsung SSD 1 TB 2.5', 'The Samsung SSD 1 TB 2.5 is a reliable solid-state drive offering ample storage capacity and fast data transfer speeds for enhanced system performance and storage needs.', 50, 80, 'HardDrive.JPEG'),
(6, 'Kingston Technology Fury Beast Black 16GB 5200MT/s DDR5', 'Kingston Fury Beast Black 16GB DDR5 RAM: High-speed performance at 5200MT/s for gaming and demanding tasks, with a sleek design to complement any build.', 40, 60, 'RAM.JPEG'),
(7, 'NZXT C750 PSU (2022) - PA-7G1BB-UK - 750 Watt PSU', 'NZXT C750 PSU: A robust 750W power supply unit, ensuring dependable performance for your PC setup with its stable power delivery.', 50, 40, 'PowerSupply.JPEG');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `productID` int(11) DEFAULT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `username`, `password`, `email`, `productID`, `role`) VALUES
(5, 'Admin', '$2y$10$im6Mm38raJcw3cP7yB43wu0dvoV.fUVU5z56rs9GgfJFMxLt./02.', 'Admin@Admin.com', NULL, 'admin'),
(8, 'mahmood', '$2y$10$dSqjDl8ZIB0ewC39P8zjqOf/gCwJH75RKx473pZqp9/pEF6eddkna', 'Mahmood@hotmail.com', NULL, 'user'),
(9, 'user', '$2y$10$LC05BIYs2O/4eDz5wX.v0eac8crG.P4vfAXA/H1nlGeP1SGorP23q', 'user@hotmai.com', NULL, 'user'),
(10, 'hassan', '$2y$10$an.CH4FUVwdF6/Q9MFbh6u7Xh2cYlOVtttOUnkwTTQBCsRRZ01BaO', 'hassan@hotmail.com', NULL, 'user'),
(13, 'ali', '$2y$10$887DKcsXPjTVkUvjeK8mcOINxe4c3KFhLT1XHYX7BT64aBhu7stR2', 'ali@hotmail.com', NULL, 'user'),
(14, 'Ahmed', '$2y$10$uEj5YY2kj70bLPCGFxA4EeQwqPi450n/Bfqz4haBX15GRCdrymfSK', 'Ahmed@hotmail.com', NULL, 'user'),
(16, 'test', '$2y$10$cFCl05KF9Fp7oe7kh/Y7GuGFOgLNe/PvtcUC87rLAnc0JwoUN9k0q', 'test@hotmail.com', NULL, 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `fk_userID` (`userID`),
  ADD KEY `fk_order_product` (`product_id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_product_id`),
  ADD KEY `orderID` (`orderID`),
  ADD KEY `productID` (`product_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `productID` (`productID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `order_product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_order_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  ADD CONSTRAINT `fk_userID` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products_ibfk_1` FOREIGN KEY (`orderID`) REFERENCES `orders` (`orderID`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
