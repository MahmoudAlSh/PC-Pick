<?php
// Include database connection
include 'Database.php';

// Check if item ID is provided
if(isset($_POST['itemId'])) {
    // Sanitize the item ID
    $itemId = filter_var($_POST['itemId'], FILTER_SANITIZE_NUMBER_INT);

    // Prepare a DELETE statement
    $sql = "DELETE FROM product WHERE product_id = ?";

    // Prepare the statement
    $stmt = $conn->prepare($sql);

    // Bind the parameter
    $stmt->bind_param("i", $itemId);

    // Execute the statement
    if($stmt->execute()) {
        // Item deleted successfully
        echo "Item deleted successfully.";
        header("Location: Admin.php");
        exit(); 
    } else {
        // Failed to delete the item
        echo "Failed to delete the item: " . $conn->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>
