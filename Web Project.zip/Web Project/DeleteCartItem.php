<?php
// Check if a session is not already active before starting a new one
if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Start session to access session variables
}

// Check if product_id is provided
if(isset($_POST['product_id'])) {
    // Retrieve product ID from the POST request
    $product_id = $_POST['product_id'];

    // Check if the cart session variable exists
    if(isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        // Loop through the cart items to find the one to delete
        foreach ($_SESSION['cart'] as $key => $item) {
            if ($item['product_id'] == $product_id) {
                // Remove the item from the cart array
                unset($_SESSION['cart'][$key]);
                // Redirect the user back to the cart page after successful removal
                header("Location: Cart.php");
                exit(); // Stop further execution
            }
        }
        // If the product was not found in the cart
        http_response_code(404);
        echo json_encode(['error' => 'Product not found in cart.']);
    } else {
        // If the cart session variable doesn't exist or is empty
        http_response_code(404);
        echo json_encode(['error' => 'Cart is empty.']);
    }
} else {
    // If product_id is not provided
    http_response_code(400);
    echo json_encode(['error' => 'Product ID is not provided.']);
}
?>

