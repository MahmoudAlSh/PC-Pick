<?php
session_start(); // Start session

include 'Database.php'; // Include database connection

$error = ""; // Initialize error variable

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize form inputs
    $username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_SPECIAL_CHARS);
    $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_SPECIAL_CHARS);

    // Prepare SQL statement to fetch user details
    $st = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $st->bind_param("s", $username);
    $st->execute();
    $result = $st->get_result();

    // Check if user exists
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        // Verify password
        if (password_verify($password, $row['password'])) {
            // Password is correct, set session variables
            $_SESSION['username'] = $username;
            
            // Fetch user ID from the database
            $userID = $row['userID']; // Assuming the column name is 'userID' in your database
            
            // Set userID in session
            $_SESSION['userID'] = $userID;
            
            // Determine user role and redirect accordingly
            if ($row['role'] == 'admin') {
                // Redirect admin to admin page
                header("Location: Admin.php");
            } else {
                // Redirect regular user to main page
                header("Location: Mainpage.php");
            }
            exit();
        } else {
            // Incorrect password
            $error = "Incorrect password";
        }
    } else {
        // User does not exist
        $error = "User does not exist";
    }
}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="Login.css">
    <title>Login Page</title>
</head>
<body>
<div class="login-container">
    <h2>Login</h2>
    <?php if (!empty($error)) echo "<p style='color: red;'>$error</p>"; ?> <!-- Display error message -->
    <form action="Login.php" method="post">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="form-group">
            <input type="submit" value="Login">
        </div>
    </form>
    <p>Don't have an account? <a href="register.html">Register here</a>.</p>
</div>
</body>
</html>

